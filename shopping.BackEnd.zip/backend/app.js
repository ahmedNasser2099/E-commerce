require('./database')
const express = require('express');
const mongoose = require('mongoose');
const usersController = require('./controllers/usersController');
const productsController = require('./controllers/productsController');
const cartController = require('./controllers/cartController');
const CartRoutes = require('./routes/cart');
require('dotenv').config();

const app = express();
const cors = require('cors');

// Middleware to parse JSON bodies
app.use(cors());
app.use(express.json());
//app.use('/cart', CartRoutes);
app.use('/api/cart', CartRoutes);

// User routes
app.post('/api/data', (req, res) => {
    const data = req.body;
});
app.post('/api/users/register', usersController.registerUser);
app.post('/api/users/login', usersController.loginUser);
app.delete('/api/users/:id', usersController.deleteUser);
app.put('/api/users/:id', usersController.updateUser);
app.get('/api/users/:id', usersController.getUser);
app.get('/api/users', usersController.getUsers);

// Product routes
app.post('/api/products', productsController.createProduct);
app.put('/api/products/:id', productsController.updateProduct);
app.delete('/api/products/:id', productsController.deleteProduct);
app.get('/api/products/:id', productsController.getProduct);
app.get('/api/products', productsController.getProducts);

// cart routes
//app.post('/api/cart', cartController.getProduct);
//app.delete('/api/cart/:id', cartController.deleteProduct);
///app.get('/api/products/:id', cartController.getProduct);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));