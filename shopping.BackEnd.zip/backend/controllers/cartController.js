const Cart = require('../models/Cart');
const Product = require('../models/Product');

exports.addToCart = async (req, res) => {
  // Find cart by user id
  let cart = await Cart.findOne({ userId: req.user._id });

  // If cart does not exist, create a new one
  if (!cart) {
    cart = new Cart({ userId: req.user._id, products: [{ productId: req.body.productId, quantity: req.body.quantity || 1 }] });
  } else {
    // If cart exists, find product in cart
    let productIndex = cart.products.findIndex(p => p.productId.toString() === req.body.productId);

    // If product exists in cart, increase quantity, else add new product to cart
    if (productIndex > -1) {
      cart.products[productIndex].quantity += req.body.quantity || 1;
    } else {
      cart.products.push({ productId: req.body.productId, quantity: req.body.quantity || 1 });
    }
  }

  // Save cart
  await cart.save();

  // Send response
  res.send(cart);
};

exports.removeFromCart = async (req, res) => {
  // Find cart by user id
  let cart = await Cart.findOne({ userId: req.user._id });

  // If cart does not exist, return error
  if (!cart) return res.status(404).send('Cart not found.');

  // If cart exists, find product in cart
  let productIndex = cart.products.findIndex(p => p.productId.toString() === req.params.productId);

  // If product exists in cart, remove it, else return error
  if (productIndex > -1) {
    cart.products.splice(productIndex, 1);
  } else {
    return res.status(404).send('Product not found in cart.');
  }

  // Save cart
  await cart.save();

  // Send response
  res.send(cart);
};

exports.getCart = async (req, res) => {
  // Find cart by user id
  let cart = await Cart.findOne({ userId: req.user._id }).populate("products.productId");

  if (!cart) return res.status(404).send('Cart not found.');

  // Send response
  res.send(cart);
};