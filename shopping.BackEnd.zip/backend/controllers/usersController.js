const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.registerUser = async (req, res) => {
  // Check if user already exists
  let user = await User.findOne({ email: req.body.email });
  if (user) return res.status(400).send('User already registered.');

  // Create new user
  user = new User(req.body);

  // Hash password
  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(user.password, salt);

  // Save user
  await user.save();
  
  // Generate token
  const token = jwt.sign({ id: user._id }, process.env.JWT_PRIVATE_KEY);

  // Send response
  res.header('x-auth-token', token).send({
    id: user.length +1,
    name: user.name,
    email: user.email
  });
};

exports.loginUser = async (req, res) => {
  // Find user
  let user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(400).send('Invalid email or password.');

  // Check password
  const validPassword = await bcrypt.compare(req.body.password, user.password);
  if (!validPassword) return res.status(400).send('Invalid email or password.');

  // Generate token
  const token = jwt.sign({ id: user._id }, process.env.JWT_PRIVATE_KEY);

  // Send response
  res.send(token);
};

exports.deleteUser = async (req, res) => {
  // Get the user from DB using the id from the token
  const admin = await User.findById(req.user.id);

  // Check if user is admin
  if (!admin.isAdmin) return res.status(403).send('Access denied. You are not an admin.');

  // Find user
  let user = await User.findByIdAndRemove(req.params.id);
  if (!user) return res.status(404).send('The user with the given ID was not found.');

  // Send response
  res.send(user);
};


exports.updateUser = async (req, res) => {
  // Get the user from DB using the id from the token
  const admin = await User.findById(req.user.id);

  // Check if user is admin
  if (!admin.isAdmin) return res.status(403).send('Access denied. You are not an admin.');

  // Find and update user
  let user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!user) return res.status(404).send('The user with the given ID was not found.');

  // Send response
  res.send(user);
};


exports.getUser = async (req, res) => {
  // Find user
  let user = await User.findById(req.params.id);
  if (!user) return res.status(404).send('The user with the given ID was not found.');

  // Send response
  res.send(user);
};

exports.getUsers = async (req, res) => {
  // Get all users
  const users = await User.find();
  
  // Send response
  res.send(users);
};